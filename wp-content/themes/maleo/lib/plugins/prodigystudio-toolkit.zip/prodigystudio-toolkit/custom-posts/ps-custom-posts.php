<?php

/* REGISTER CUSTOM POSTS FOR PORTFOLIO */


function ps_portfolio_register() {
	
	global $ps_opts;
	
	if(isset($ps_opts['ps_portfolio_item_rewrite'])) $item_portfolio_url = $ps_opts['ps_portfolio_item_rewrite']; else $item_portfolio_url = 'portfolio';
	if(isset($ps_opts['ps_portfolio_tax_rewrite'])) $tax_portfolio_slug = $ps_opts['ps_portfolio_tax_rewrite']; else $tax_portfolio_slug = 'portfolios';
 	
	
	register_post_type( 'portfolio' ,
	 array(
		'labels' => array(
		'name' => _x('Portfolio', 'post type general name','prodigystudio'),
		'singular_name' => _x('Portfolio Item', 'post type singular name','prodigystudio'),
		'add_new' => _x('Add New', 'theme item','prodigystudio'),
		'add_new_item' => __('Add New','prodigystudio'),
		'edit_item' => __('Edit','prodigystudio'),
		'new_item' => __('New','prodigystudio'),
		'view_item' => __('View','prodigystudio'),
		'search_items' => __('Search','prodigystudio'),
		'not_found' =>  __('Nothing found','prodigystudio'),
		'not_found_in_trash' => __('Nothing found in Trash','prodigystudio'),
		'parent_item_colon' => ''
	),
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => '',
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'show_in_nav_menus' => false,
		'rewrite' => array( 'slug' => $item_portfolio_url, 'with_front' => false ),
		'supports' => array('title','editor','thumbnail', 'custom-fields')
	  )  
 );
 
 register_taxonomy(
	"portfolios", 
	array("portfolio"), 
	array("hierarchical" => true, 
		"label" => "Portfolio Categories", 
		"singular_label" => "Portfolio Category", 
		"rewrite" => array( 'slug' => $tax_portfolio_slug, 'with_front' => false, 'hierarchical' => true ),
		"show_in_nav_menus" => true));
	
	flush_rewrite_rules();
}

		
add_action('init', 'ps_portfolio_register');	
add_action("manage_posts_custom_column",  "portfolio_custom_columns");
add_filter("manage_edit-portfolio_columns", "portfolio_edit_columns");
function portfolio_edit_columns($columns){
  $columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Portfolio Item Title",
	"description" => "Description",
	"thumbnail" => "Thumbnail",
	"f-categories" => "Categories",
	"date" => "Date",
	
  );
 
  return $columns;
}
function portfolio_custom_columns($column){
  global $post;
  switch ($column) {
  case "thumbnail":
      the_post_thumbnail('tabsLoopThumb');
      break;
	case "description":
       echo ps_excerpt(15);
      break;		  
    case "f-categories":
      echo get_the_term_list($post->ID, 'portfolios', '', ', ','');
      break;
  }
}

add_action('init', 'team_register');
function team_register() {
 
	$labels = array(
		'name' => _x('Team', 'post type general name','prodigystudio'),
		'singular_name' => _x('Member', 'post type singular name','prodigystudio'),
		'add_new' => _x('Add New', 'Client','prodigystudio'),
		'add_new_item' => __('Add New','prodigystudio'),
		'edit_item' => __('Edit','prodigystudio'),
		'new_item' => __('New','prodigystudio'),
		'view_item' => __('View','prodigystudio'),
		'search_items' => __('Search','prodigystudio'),
		'not_found' =>  __('Nothing found','prodigystudio'),
		'not_found_in_trash' => __('Nothing found in Trash','prodigystudio'),
		'parent_item_colon' => ''
	);
 
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => '',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'show_in_nav_menus' => false,
		'supports' => array('title','editor','thumbnail')
	  ); 
 
	register_post_type( 'team' , $args );
	

}
add_action("manage_posts_custom_column",  "team_custom_columns");
add_filter("manage_edit-team_columns", "team_edit_columns");
function team_edit_columns($team_columns){
  $team_columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Member",
	"member" => "Image",
	"date" => "Date"
	
  );
 
  return $team_columns;
}
function team_custom_columns($team_columns){
  global $post;
  switch ($team_columns) {
  case "member":
 	   the_post_thumbnail('tabsLoopThumb');
  break;
  }
}



add_action('init', 'clients_register');
function clients_register() {
 
	$labels = array(
		'name' => _x('Clients', 'post type general name','prodigystudio'),
		'singular_name' => _x('Client', 'post type singular name','prodigystudio'),
		'add_new' => _x('Add New', 'Client','prodigystudio'),
		'add_new_item' => __('Add New','prodigystudio'),
		'edit_item' => __('Edit','prodigystudio'),
		'new_item' => __('New','prodigystudio'),
		'view_item' => __('View','prodigystudio'),
		'search_items' => __('Search','prodigystudio'),
		'not_found' =>  __('Nothing found','prodigystudio'),
		'not_found_in_trash' => __('Nothing found in Trash','prodigystudio'),
		'parent_item_colon' => ''
	);
 
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => '',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'show_in_nav_menus' => false,
		'supports' => array('title','thumbnail')
	  ); 
 
	register_post_type( 'clients' , $args );

}
function register_clients_taxonomy() {
	$labels_slideshow = array(
    'name' => __('Categories', 'post type general name'),
    'all_items' => __('All Categories', 'all items'),
    'add_new_item' => __('Add New Category', 'adding a new item'),
    'new_item_name' => __('New Category Name', 'adding a new item'),
);
$args_slideshow = array(
    'labels' => $labels_slideshow,
    'hierarchical' => true
);
register_taxonomy( 'clients-cats', 'clients', $args_slideshow );
}
add_action("init", "register_clients_taxonomy",1);
add_action("manage_posts_custom_column",  "clients_custom_columns");
add_filter("manage_edit-clients_columns", "clients_edit_columns");
function clients_edit_columns($clients_columns){
  $clients_columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Client",
	"logo" => "Logo",
	"date" => "Date"
	
  );
 
  return $clients_columns;
}
function clients_custom_columns($clients_columns){
  global $post;
  switch ($clients_columns) {
  case "logo":
 	   the_post_thumbnail('tabsLoopThumb');
  break;
  }
}




add_action('init', 'testimonies_register');
function testimonies_register() {
 
	$labels = array(
		'name' => _x('Testimonies', 'post type general name','prodigystudio'),
		'singular_name' => _x('Testimony', 'post type singular name','prodigystudio'),
		'add_new' => _x('Add New', 'testimony item','prodigystudio'),
		'add_new_item' => __('Add New','prodigystudio'),
		'edit_item' => __('Edit','prodigystudio'),
		'new_item' => __('New','prodigystudio'),
		'view_item' => __('View','prodigystudio'),
		'search_items' => __('Search','prodigystudio'),
		'not_found' =>  __('Nothing found','prodigystudio'),
		'not_found_in_trash' => __('Nothing found in Trash','prodigystudio'),
		'parent_item_colon' => ''
	);
 
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => true,
		'show_ui' => true,
		'query_var' => true,
		'menu_icon' => '',
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_position' => null,
		'show_in_nav_menus' => false,
		'supports' => array('title','editor','thumbnail')
	  ); 
  	
	register_post_type( 'testi' , $args );	
}
add_action("manage_posts_custom_column",  "testi_custom_columns",5,2);
add_filter("manage_edit-testi_columns", "testi_edit_columns", 5);
function testi_edit_columns($testi_columns){
  $testi_columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Author",
	"logo" => "Image",
	"wps_post_id" => "Testimonie ID",
	
  );
 
  return $testi_columns;
}
function testi_custom_columns($testi_columns, $id){
  global $post;
  switch ($testi_columns) {
  case "logo":
 //	   the_post_thumbnail('tabsLoopThumb');
  break;
  }
}

function ps_add_menu_icons_styles(){
?>
<style>
	#adminmenu .menu-icon-portfolio div.wp-menu-image:before {content: '\f322';}
	#adminmenu .menu-icon-team div.wp-menu-image:before {content: "\f338";}
	#adminmenu .menu-icon-testi div.wp-menu-image:before {content: "\f473";}
	#adminmenu .menu-icon-clients div.wp-menu-image:before {content: "\f307";}
</style>
<?php
	}
add_action( 'admin_head', 'ps_add_menu_icons_styles' );
?>