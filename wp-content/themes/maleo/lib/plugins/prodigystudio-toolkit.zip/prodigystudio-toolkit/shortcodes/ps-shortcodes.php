<?php
//Shortcode for year
function ps_year_shortcode_function() {
    $year = date('Y');
	return $year;
}
function ps_copyright_shortcode_function() {
	return '&copy;';
}
function ps_sitename_shortcode_function() {
	$sitename = get_bloginfo('name');
	return $sitename;
}
function ps_sitetagline_shortcode_function() {
	$sitetagline = get_bloginfo('description');
	return $sitetagline;
}
function ps_themecredit_shortcode_function() {
	$my_theme = wp_get_theme();
	$output = '- Multifunctional WordPress Theme by '.$my_theme->{'Author'};
	return $output;
}

function ps_wpurl_shortcode_function() {
	$ps_wpurl = site_url();
	return $ps_wpurl;
}
function ps_siteurl_shortcode_function() {
	$ps_siteurl = get_bloginfo('siteurl');
	return $ps_siteurl;
}
function ps_template_url_shortcode_function() {
	$ps_templateurl = get_template_directory_uri();
	return $ps_templateurl;
}
function ps_login_url_shortcode_function() {
	$ps_loginurl = wp_login_url();
	return $ps_loginurl;
}
function ps_logout_url_shortcode_function() {
	$ps_logouturl = wp_logout_url();
	return $ps_logouturl;
}

function prodigystudio_register_shortcodes(){
	add_shortcode('current-year', 'ps_year_shortcode_function');
	add_shortcode('copyright', 'ps_copyright_shortcode_function');
	add_shortcode('site-name', 'ps_sitename_shortcode_function');
	add_shortcode('site-tagline', 'ps_sitetagline_shortcode_function');
	add_shortcode('theme-credit', 'ps_themecredit_shortcode_function');
	add_shortcode('wp-url', 'ps_wpurl_shortcode_function');
	add_shortcode('site-url', 'ps_siteurl_shortcode_function');
	add_shortcode('theme-url', 'ps_template_url_shortcode_function');
	add_shortcode('login-url', 'ps_login_url_shortcode_function');
	add_shortcode('logout-url', 'ps_logout_url_shortcode_function');
	add_shortcode('homepage-gallery', 'ps_gallery');
	add_shortcode('post-gallery', 'ps_post_slider');
}
add_action( 'init', 'prodigystudio_register_shortcodes');
add_filter('widget_text', 'do_shortcode');

if ( !function_exists('ps_column') ) {
	function ps_column( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'column' => 'one-third',
			'text_align' => 'text-left',
			'effect' => 'noAnimation',
			'gap_top' => 'default',
			'gap_bottom' => 'default'
		), $atts));
		
		$gap_top_class = '';
		$gap_bottom_class = '';
		$text_align_class = '';
		
		if($gap_top != 'default') {
			$gap_top_class = ' gap-top'.$gap_top;
		 }
		 if($gap_bottom != 'default') {
			$gap_bottom_class = ' gap-bottom'.$gap_bottom;
		 }		 
		 if($text_align != 'text-left') {
			$text_align_class = ' '.$text_align;
		 }
		 
		
		$columns = array(
			'one-full' => 'large-12 medium-12', 
			'one-third' => 'large-4 medium-4',
			'two-thirds' => 'large-8 medium-8',
			'one-half' => 'large-6 medium-6',
			'one-fourth' => 'large-3 medium-3',
			'three-fourth' => 'large-9 medium-9',
			'one-sixth' => 'large-2 medium-2',
			'five-sixth' => 'large-10 medium-10'
		);
		$column_class = $columns[$column];
		
		$effect_class = '';
		$effect_data = '';
		if($effect != 'noAnimation') {
			$effect_class = ' triggerAnimation animated';
			$effect_data = ' data-animate="'.$effect.'"';
		}

		return '<div class="'. $column_class .' columns '.$text_align_class . $effect_class . $gap_top_class . $gap_bottom_class . '"'.$effect_data.' >' . do_shortcode($content) . '</div>';
	}
	add_shortcode('ps_column', 'ps_column');
}

/* Legacy shortcodes --- */
if (!function_exists('ps_br')) {
	function ps_br ( $atts, $content = null){
		return '<br class="nobr">';
	}
	add_shortcode('ps_br','ps_br');
}
if (!function_exists('ps_pre')) {
	function ps_pre ( $atts, $content = null){
		return '<pre>'. $content .'</pre>';
	}
	add_shortcode('ps_pre','ps_pre');
}

/* Tables ----- */

if (!function_exists('ps_table')) {
	function ps_table( $atts, $content = null) {
		extract (shortcode_atts(array(
			'color' => '',
		), $atts));
		
		$table_color = '';	
		if($color != '') { $table_color = 'table-'.$color; }
		
		return '<table class="'.$table_color.'">'.$content.'</table>';
	}
	add_shortcode('ps_table','ps_table');
}


/* --- Panel box --- */

if (!function_exists('ps_panel')) {
	function ps_panel( $atts, $content =  null) {
		extract (shortcode_atts(array(
			'color' => '',
			'types' => ''			
		), $atts));
		
	$color_class = '';
	$type_class = '';
	if($color != 'default'){
		$color_class = ' '.$color;
	}
	if($type != 'default'){
		$type_class = ' '.$types;
	}
	
	return '<div class="panel ' . $type_class . $color_class . '">' . do_shortcode($content) . '</div>'; 		
		
	}
	add_shortcode('ps_panel','ps_panel');

}

/* --- Promo box --- */

if (!function_exists('ps_promo')) {
	function ps_promo( $atts, $content = null) {
		extract (shortcode_atts(array(
			'color' => '',
			'title' => '',
			'icon' => '',
			'shape' => '',			
			'link' => '',
			'link_label' => 'Buy it now',
			'ps_animation' => '',
			'ps_animation_delay' => '',
	    ), $atts));
		
		
		$link = ($link=='||') ? '' : $link;
		$link = ps_build_link( $link );
		$a_href = $link['url'];
		$a_title = $link['title'];
		$a_target = $link['target'];
		
		
		$effect_class = '';
		$effect_data = '';
		$promo_color = '';
		if($color !='') { 
			$promo_color = $color;
		}
		$animation = '';
		$animation_delay = '';
		$data_animation = '';

		if($ps_animation != 'noAnimation') { 
				$animation = 'mo-animate'; $data_animation = psAnimation($ps_animation); 
			};
		if($ps_animation != 'noAnimation' && $ps_animation_delay != '' ) {
				$animation_delay = 'data-delay="'.$ps_animation_delay.'"';
			}
			
		$output = '';
				
		
		
		return '<div class="promo-box ' . $promo_color .' '.$animation.'" '.$data_animation.' '.$animation_delay.'>
  <div class="promo-text">
    <div class="feature-left">
      <div class="'.$shape.' small '.$promo_color .' style2"> <i class="'.$icon.'"></i> </div>
      <h3>'.$title.'</h3>
      <p>' . do_shortcode($content) . '</p>
    </div>
  </div>
  <div class="promo-button"> <a href="'. $a_href .'" title="'.$a_title.'" target="'.$a_target.'">
    <h3>'. $link_label .'</h3>
    <i class="icon-chevron-right"></i> </a> </div>
</div>
';
}

	add_shortcode('ps_promo', 'ps_promo');
}

/*  --- Icons --- */

if(!function_exists('ps_icon')) {
	function ps_icon( $atts, $content = null) {
		extract (shortcode_atts(array(
			'icon' => '',
			'border' => 'no-border',
			'color' => '',
			'size' => '',
			'align' => '',
			'icon_special' => '',			
			'el_class' => ''
		
		), $atts));
		$align = 'icon-'.$align;
				if ($icon_special != '') {
					return '<i class="'.$icon.' '.$icon_special.'"></i>';	
				} else {
					return '<div class="'.$border.' '.$color.' '.$size.' '.$align.' '.$el_class.'"><i class="'.$icon.' '.$icon_special.'"></i></div>';		
				}
	}
	add_shortcode('ps_icon','ps_icon');
}

/*  --- Counter panel --- */

if(!function_exists('ps_counter')) {
	function ps_counter ( $atts, $content = null) {
		extract (shortcode_atts(array(
			'title' => '',
			'icon' => '',
			'number' => ''			
		
		), $atts));
		
		$output = '';		
		$output .= '<div class="company-fact">';
		if($icon) {   
			$output .= '<div class="no-shape large"><i class="'.$icon.'"></i></div>';
		}; 		
		$output .= '<h1 class="mo-counter timer" data-to="'.$number.'" data-speed="2500">'.$number.'</h1>';
		if($title) {   
			$output .= '<p>'.$title.'</p>';
		}
		$output .= '</div>';
		$output .= '</div>';
		
		return $output;

	}
		add_shortcode('ps_counter','ps_counter');
}


/* --- ProdigyStudio Separator/divider --- */

if(!function_exists('ps_separator')) {
	function ps_separator( $atts, $content = null) {
		extract (shortcode_atts(array(
			'el_class' => '',		
		), $atts));

		return '<div class="large-12 columns separator '.$el_class.'"><hr></div>';
	}
	add_shortcode('ps_separator', 'ps_separator');
}

/* --- ProdigyStudio Service Grid Container --- */

if(!function_exists('ps_service_grid_container')) {
	function ps_service_grid_container( $atts, $content = null) {
		extract (shortcode_atts(array(
			'title' => '',
			'subtitle' => ''
		), $atts));
		
		
		$title_html = '';
		$subtitle_html = '';
		if($title != '' ) {$title_html = '<h4 class="title-service mo-animate" data-animate="fadeInDown">'.$title.'</h4>';}
		if($subtitle != '' ) {$subtitle_html = '<h6 class="sub-service mo-animate" data-animate="fadeInDown" data-delay="200"><span>'.$subtitle.'</span></h6>';}
		
		return $title_html . $subtitle_html .'<ul class="large-block-grid-4 medium-block-grid-4 medium-potrait-block-grid-2 no-gutter service-list">'.do_shortcode( $content ).'</ul>';
	}
	add_shortcode('ps_service_grid_container','ps_service_grid_container');
}

/* --- ProdigyStudio Service Grid --- */

if(!function_exists('ps_service_grid')) {
	function ps_service_grid( $atts, $content = null) {
		extract (shortcode_atts(array(
			'title' => '',			
			'icon' => '',
			'ps_animation' => '',
			'ps_animation_delay' => '',
			
		), $atts));
				
		$animation = '';
		$animation_delay = '';
		$data_animation = '';

		if($ps_animation != 'noAnimation') { 
				$animation = 'class="mo-animate"'; $data_animation = psAnimation($ps_animation); 
			};
		if($ps_animation != 'noAnimation' && $ps_animation_delay != '' ) {
				$animation_delay = 'data-delay="'.$ps_animation_delay.'"';
			}
			
		$output = '';
		
		$output .= '<li '.$animation.' '.$data_animation.' '.$animation_delay.'>
                     <div class="feature">
                        <div class="circle-bg">
                           <i class="small '.$icon.'"></i>
                        </div>
                        <h6>'.$title.'</h6>
                        <p>'.$content.'</p>
                     </div>
                  </li>';	

		return $output;
	}
	add_shortcode('ps_service_grid','ps_service_grid');
}



/* --- ProdigyStudio Google Subscribe Form --- */

if(!function_exists('ps_subscribe')) {
	function ps_subscribe($atts, $content = null) {
		extract (shortcode_atts(array(
			'title' => 'Subscribe Newsletter',
			'description' => '',
			'user_uri' => '',
			'loc' => 'en_EN'
		
		), $atts));
		
		if($title != '' ) {$title_text = '<h4>'.$title.'</h4>';}
		if($description != '' ) {$description_text = '<p class="gap-bottom8">'.$description.'</p>';}
			
		return '<div class="newsletter-box">'.$title_text.''.$description_text.'<form action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open(\'http://feedburner.google.com/fb/a/mailverify?uri='.$user_uri.'\', \'popupwindow\', \'scrollbars=yes,width=550,height=520\');return true" id="comment-form">
		<fieldset> 
        	<input type="text" name="name" id="name" placeholder="Username" />
			<input type="email" name="email" id="email" placeholder="Email here" />
			<input type="hidden" value="'.$user_uri.'" name="uri" />
			<input type="hidden" name="loc" value="'.$loc.'"/>   
			<div class="clear"></div> 
			<button type="submit" class="small round green" id="buttonsend">'.__('Subscribe', 'webincode').'</button>
		</fieldset>
		</form>
		</div>';
	}
	add_shortcode('ps_subscribe', 'ps_subscribe');
}


/* --- Featured box with icons --- */

if(!function_exists('ps_featured_icon')) {
	function ps_featured_icon( $atts, $content = null) {
		extract (shortcode_atts(array(
			'icon' => '',
			'size' => '',
			'color' => '',
			'align' => '',
			'customtitlecolor' => '',
			'shape' => '',
			'title' => '',
			'box_type' => ''
			
			), $atts));		
			
						
			if($customtitlecolor != '' ) { $customtitlecolor = 'style="color:'.$customtitlecolor.'"';  }
			if($title != '') { $title_html = '<h4 '.$customtitlecolor.'>'.$title.'</h4>';}

			$align_html = '';
			$gap = '';			
			$gap_data = '';
			if($align != '' && $align != 'center' ) {$align_html = '-'.$align;} 
			if($align == 'right') { 
				$gap = ' gap';
				$gap_data = 'data-top="-15"';
			}
			if($align == 'left') { 
				$gap = ' gap';
				$gap_data = 'data-top="-10"';
			}
			if($box_type == 'special') :

				return '<div class="feature'.$align_html.'">
                     <div class="no-shape">
                        <i class="small '.$icon.$gap.'" '.$gap_data.'></i>
                     </div>    
                     	<h4 class="maleo-color" '.$customtitlecolor.'>'.$title.'</h4> 
                     <p>'.$content.'</p>
                  </div>';
	
			else:

				return '<div class="feature'.$align_html.'">
                  <div class="'.$shape.' small style3 '.$color.'">
                     <i class="'.$icon.'"></i>
                  </div>    
                  <h5 class="gap" data-bottom="12" '.$customtitlecolor.'>'.$title.'</h5> 
                  <p>'.$content.'</p>
               </div>';		
		
			endif;
	}
	add_shortcode('ps_featured_icon','ps_featured_icon');
}

/* --- ProdigyStudio Annotation --- */

if(!function_exists('ps_annotation_container')) {
	function ps_annotation_container( $atts, $content = null) {
		
		return '<div class="content-annotation">' . do_shortcode($content ) . '</div>';

	}	
	add_shortcode('ps_annotation_container','ps_annotation_container');
}

if(!function_exists('ps_annotation')) {
	function ps_annotation( $atts, $content = null) {
		extract (shortcode_atts(array(
			'align' => '',
			'images' => '',
			'ps_animation' => ''			
		
		
		), $atts));
		
		
		
		$animation = '';
		$data_animation = '';
		if($ps_animation != 'noAnimation') { $animation = ' triggerAnimation animated '; $data_animation = 'data-animate="'.$ps_animation.'"'; };
		$attachments = array_filter( explode( ',', $images ) );		
		$output = '';
		
		switch($align) {
			
		case "left":
			$output .= '<div class="left-annotation">';
				if ( $attachments )
				$i = 0;
    	        foreach ( $attachments as $attachment_id ) {
					$i++;
					$thumb_image_data = wp_get_attachment_image_src( $attachment_id, 'annotationThumbs');
					$img_meta = get_post($attachment_id);
					$img_description = $img_meta->post_excerpt;
					$image_src = $thumb_image_data['0'];
	  	        if($i <= 3) { $output .= '<div class="img-annotation left-arrow'.$i.' triggerAnimation animated" data-animate="bounceInLeft"> <span data-tooltip class="has-tip tip-left" title="'.$img_description.'"> <img src="'.$image_src.'" alt=""/> </span> </div>'; }
				
        	}			
			
			$output .= '</div>';
		break;
		
		case "center":
			$output .= '<div class="center-annotation triggerAnimation animated" data-animate="bounceIn">';
				if ( $attachments )
				$i = 0;
    	        foreach ( $attachments as $attachment_id ) {
					$i++;
					$thumb_image_data = wp_get_attachment_image_src( $attachment_id, 'full');
					$img_meta = get_post($attachment_id);
					$img_description = $img_meta->post_excerpt;
					$image_src = $thumb_image_data['0'];
	  	        if($i <= 1) { $output .= ' <img src="'.$image_src.'" alt="" class="img-center"> '; }
				
        	}			
			
			$output .= '</div>';
		break;
		
		
		case "right":
			$output .= '<div class="right-annotation">';
				if ( $attachments )
				$i = 0;
    	        foreach ( $attachments as $attachment_id ) {
					$i ++;
					$thumb_image_data = wp_get_attachment_image_src( $attachment_id, 'annotationThumbs');
					$img_meta = get_post($attachment_id);
					$img_description = $img_meta->post_excerpt;
					$image_src = $thumb_image_data['0'];
	  	        if($i <= 3) { $output .= '<div class="img-annotation right-arrow'.$i.' triggerAnimation animated" data-animate="bounceInRight"> <span data-tooltip class="has-tip tip-right" title="'.$img_description.'"> <img src="'.$image_src.'" alt=""/> </span> </div>'; }
				
        	}			
			
			$output .= '</div>';
		break;
			
		
		
		
		}
		
		return $output;

	}
	add_shortcode('ps_annotation','ps_annotation');
}


/* --- ProdigyStudio Contact Form --- */

if(!function_exists('ps_contact_form')) {
	function ps_contact_form ( $atts, $content = null) {
		extract (shortcode_atts(array(
			'title' => '',								
		
		), $atts));

		ob_start();	
		pscf_html($title);
		return ob_get_clean();
	}
	add_shortcode('ps_contact_form','ps_contact_form');
}


/* --- Panel with icons --- */

if(!function_exists('ps_panel_icon')) {
	function ps_panel_icon( $atts, $content = null) {
		extract (shortcode_atts(array(
			'icon' => '',
			'color' => '',
			'title' => ''				
			
			), $atts));		
		
			
					
			$output = '';
			
			$output = '<div class="feature-offset panel">
                  <div class="circle-shape '.$color.' style3">                           
                     <i class="'.$icon.'"></i>
                  </div>                    
                  <h4>'.$title.'</h4> 
                  <p>'.$content.'</p>
               </div>';
		
		return $output;
	}
	add_shortcode('ps_panel_icon','ps_panel_icon');
}



/* --- Blog carousel --- */

if(!function_exists('ps_blog_carousel')) {
function ps_blog_carousel($atts, $content = null) {
	extract(shortcode_atts(array(		
		'cats' => '',
		'charlimit' => '60',
		'show_items' => '12'
		
		), $atts));
		
	global $post;

	$selected_categories = array();
	
	if ($cats != '') {$selected_categories = explode(',', $cats);
		} else { $blog_category = get_terms('category');
			if($blog_category):
					foreach($blog_category as $blog_cat):
						array_push($selected_categories,$blog_cat->slug);
					endforeach;
			
			$selected_categories = implode (',',$selected_categories);
			endif;
		}
	if ($cats == '') { 
	$args = array(
				'showposts' => $show_items,
			);
	} else {
	$args = array(
				'showposts' => $show_items,
				'tax_query' => array(
        array(
            'taxonomy' => 'category',
            'field' => 'slug',
            'terms' => $selected_categories
    	    )
	    )
	);
}
	$blog_items = new WP_Query($args);
	$output = '';
	$output .= '<div id="content-carousel" class="owl-carousel">';
	
	while($blog_items->have_posts()): $blog_items->the_post();

	$thumb = '';
	$author = get_the_author_meta('user_nicename');
	$short_title = ps_short_title('...',23);
	$num_comments = get_comments_number();
		
	$content = get_the_content();
	$content = strip_tags($content); 
	$content = substr($content, 0, $charlimit).' ...';
	
	if(has_post_thumbnail()){
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'carouselThumbs' );
			$full_size = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'full' );
	}	
	
	if(!empty($thumb['0'])) { $src_thumb = $thumb['0']; } else { $src_thumb = ''; }
	if(!empty($full_size['0'])) { $src_full = $full_size['0']; } else { $src_full = ''; }

	
	$output .= '<div class="item cs-style-1">';
	$output .= '<figure>';
	$output .= '<div> <img src="'.$src_thumb.'" alt="" class="img-radius"> </div>';
	$output .= '<figcaption>';
	$output .= '<a class="fancybox" href="'.$src_full.'" data-fancybox-group="gallery" title="'.get_the_title($post->ID).'"> <i class="icon-search"></i> </a>';
    $output .= '<a href="'.get_permalink($post->ID).'"> <i class="icon-link"></i> </a>';
    $output .= '</figcaption>';
	$output .= '</figure>';
	$output .= '<a href="'.get_permalink($post->ID).'"><h5>'.$short_title.'</h5></a>';
    $output .= '<p>'.$content.'</p>';
	$output .= '<ul class="post-info no-bullet">
					<li><i class="icon-clockalt-timealt"></i>'.mysql2date('M d, Y',get_post()->post_date).'</li>
				    <li><i class="icon-user"></i><a href="'. get_author_posts_url( get_the_author_meta('ID') ).'">'.$author.'</a></li>
				    <li><i class="icon-comment"></i><a href="'.get_comments_link().'">'.$num_comments.'</a></li>
			   	</ul>';    
   $output .= '</div>';
	
	endwhile;
	wp_reset_postdata();	
	$output .= '</div>';

		return $output;
		
	}
	add_shortcode('ps_blog_carousel', 'ps_blog_carousel');	
}


/* --- custom carousel shortocode --- */

if(!function_exists('ps_custom_carousel')) {
	function ps_custom_carousel($atts, $content = null) {
		extract (shortcode_atts(array(
			'logo_cats' => '',
			'ps_animation' => '',
			'items' => ''
		), $atts));	
	
		$query_string = 'post_type=clients&showposts='.$items;
		if($logo_cats != 'all'){
			$query_string .= '&clients-cats='.$logo_cats;
		}
		$animation = '';
		$data_animation = '';
		if($ps_animation != 'noAnimation') { 
				$animation = ' mo-animate'; $data_animation = psAnimation($ps_animation); 
			};
		$args = array(
				'post_type' => 'clients',				
				'showposts' => '12',
		);
		$clients_items = new WP_Query($args);
		$output = '';
		$output .= '<ul id="carousel-testimonial" class="owl-carousel '.$animation.'" '.$data_animation.'>';

		while($clients_items->have_posts()): $clients_items->the_post();
		global $post;
		$client_url = get_post_meta($post->ID, '_ps_url_logo', true);
		$client_logo =  wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'clientsLogo' );
        if($client_url != '') {
			$output .= '<li><a href="'.$client_url.'"><img src="'.$client_logo['0'].'" alt="" class="retina" /></a></li>';
		} else {
			$output .= '<li><img src="'.$client_logo['0'].'" alt="" /></li>';
		}
        
		endwhile;
		wp_reset_postdata();               	
		$output .= '</ul>';
		
	return $output;
	
	}
	add_shortcode('ps_custom_carousel','ps_custom_carousel');
}


/* -- Clients logo grid -- */

if(!function_exists('ps_logo_grid')) {
	function ps_logo_grid( $atts, $content = null) {
		extract (shortcode_atts(array(
			'logo_cats' => '',
			'items' => ''			
		), $atts));
		
		$query_string = 'post_type=clients&showposts='.$items;
		if($logo_cats != 'all'){
			$query_string .= '&clients-cats='.$logo_cats;
		}
		
		$clients_items = new WP_Query($query_string);
		$output = '';
		$output .= '<ul class="large-block-grid-5 medium-block-grid-5 medium-potrait-block-grid-2 small-block-grid-2 small-potrait-block-grid-1 no-gutter client-list">';
		$i = 0;
		$logo = 0;
		while($clients_items->have_posts()): $clients_items->the_post();
			if($i != 0) { $delay = 'data-delay="'.$i.'"';} else { $delay = '';}
			global $post;			
			$client_url = get_post_meta($post->ID, '_ps_url_logo', true);
			$client_logo =  wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'full' );
			$output .= '<li class="mo-animate" data-animate="bounceIn" '.$delay.'><div class="mask"></div><img src="'.$client_logo['0'].'" alt=""></li>';						
			$logo++;
			$i = $i+200;
		endwhile;
		wp_reset_postdata();               	
		$output .= '</ul>';
		
		
		return $output;
		
		
		
	}
	add_shortcode('ps_logo_grid','ps_logo_grid');
}


/* Lists ----- */

if (!function_exists('ps_list')) {
	function ps_list( $atts, $content = null) {
		extract (shortcode_atts(array(
			'style' => 'no-bullet',
		), $atts));
		
		$list_style = '';	
		if($style != '') { $list_style = ''.$style; }
		
		return '<ul class="'.$list_style.'">'.$content.'</ul>';
	}
	add_shortcode('ps_list','ps_list');
}

/* Buttons --- */

if (!function_exists('ps_button')) {
	function ps_button( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'url' => '#',
			'targetlink' => '_self',
			'style' => '',
			'size' => '',
			'corners' => '',			
			'border' => '',
			'css' => ''
		), $atts));
		

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class($css, ' '), 'ps_button', $atts );				

   return '<a target="'.$targetlink.'" class="button '.$size .' '.$border.' '. $style.' '.$corners.$css_class.' " href="'.$url.'">' . do_shortcode($content) . '</a>';
	}
	add_shortcode('ps_button', 'ps_button');
}

/* Alerts --- */

if (!function_exists('ps_alert')) {
	function ps_alert( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'alert_type'   => '',
			'border' => '',
			'ps_animation' => '',
			'ps_animation_delay' => '',
			'el_class' => ''
			
	    ), $atts));
		
		
		$animation = '';
		$animation_delay = '';
		$data_animation = '';
		
		if($ps_animation != 'noAnimation') { 
				$animation = ' mo-animate '; $data_animation = psAnimation($ps_animation); 
			};
		if($ps_animation != 'noAnimation' && $ps_animation_delay != '' ) {
				$animation_delay = 'data-delay="'.$ps_animation_delay.'"';
			}		

		$icons = array(
			'default' => '&nbsp;',
			'blue' => '<i class="icon-info-sign"></i>',
			'green' => '<i class="icon-circleselect"></i>',
			'yellow' => '<i class="icon-warning-sign"></i>',
			'red' => '<i class="icon-circledelete"></i>'	
		);
		

	   return '<div class="alert-box '.$alert_type.' '.$border.' '.$animation.'" '.$data_animation.' '.$animation_delay.'>'.$icons[$alert_type].' '.do_shortcode($content).'<a data-component="alert" href="#" class="close">&times;</a></div>';
	}
	add_shortcode('ps_alert', 'ps_alert');
}

/* --- Headline Shortcodes --- */

if(!function_exists('ps_headline')) {
	function ps_headline( $atts, $content = null) {
		extract(shortcode_atts(array(
			'subtitle' => '',
			'cssclass' => '',
			'customtitlecolor' => '',
			'heading_tag' => '',
			'css' => ''
			
		), $atts));
		
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $cssclass.vc_shortcode_custom_css_class($css, ' '), 'ps_headline', $atts );		
		$el_class = 'class="'.$css_class.'"';
		$subtitle_html = '';		
		if($subtitle != '') {$subtitle_html = '<h2 class="maleo-color">'.$subtitle.'</h2>';}
		
		if($customtitlecolor != '' ) { $customtitlecolor = 'style="color:'.$customtitlecolor.'"';  }
	
		return '<span class="heading-line"></span><'.$heading_tag.' '.$el_class.' '.$customtitlecolor.'>'.$content.'</'.$heading_tag.'>'.$subtitle_html;	
	}
	

	add_shortcode('ps_headline','ps_headline');
}

if(!function_exists('ps_tab_headline')) {
	function ps_tab_headline( $atts, $content = null) {
		extract(shortcode_atts(array(
			'title' => '',
			'subtitle' => '',
			
		), $atts));
		
		if($subtitle != '' ) {$tab_subtitle = '<p>'.$subtitle.'</p>';}
		return '<div class="reva-tabs-title"><h4>'.$title.'</h4>'.$tab_subtitle.'</div>';	
	}

	add_shortcode('ps_tab_headline','ps_tab_headline');
}

/* --- Single Image --- */

if(!function_exists('ps_single_image')) {
	function ps_single_image( $atts, $content = null) {
		extract(shortcode_atts(array(
			'image' => '',			
			'alignment' => '',
			'img_size' => '',
			'ps_animation' => '',
			'el_class' => ''			
			
		), $atts));
		
		$animation = '';
		$data_animation = '';
		if($img_size == '') {$img_size = 'full';}
		if($ps_animation != 'noAnimation') { $animation = ' mo-animate '; $data_animation = 'data-animate="'.$ps_animation.'"'; };
		
		$image_data = wp_get_attachment_image_src( $image, $img_size);
		$image_src = $image_data['0'];

		return '<img class="'.$el_class.' '.$animation.'" '.$data_animation.' src="'.$image_src.'" />';
	
	}

	add_shortcode('ps_single_image','ps_single_image');
}


if(!function_exists('ps_fancybox_list')) {
	function ps_fancybox_list($atts, $content = null ) {
		extract(shortcode_atts(array(
			'images' => '',
			'ps_animation' => ''
			
			), $atts));
		
		$animation = '';
		$data_animation = '';
		if($ps_animation != 'noAnimation') { $animation = ' mo-animate '; $data_animation = 'data-animate="'.$ps_animation.'"'; };
		$attachments = array_filter( explode( ',', $images ) );
        
		$output = '';
		$output .= '<div id="carousel-team">';
		     if ( $attachments )
    	        foreach ( $attachments as $attachment_id ) {
					$thumb_image_data = wp_get_attachment_image_src( $attachment_id, 'carouselThumbs');
					$full_image_data = wp_get_attachment_image_src( $attachment_id, 'full');
					$img_meta = get_post($attachment_id);
					$img_description = $img_meta->post_content;
					$image_src = $thumb_image_data['0'];
					$full_image_src = $full_image_data['0'];
	  	         $output .= '<li><a href="'.$full_image_src.'" class="fancybox" title="'.$img_description.'" data-fancybox-group="gallery" ><img src="'.$image_src.'"></a></li>';
        	} 	
		$output .= '</div>';	
		
		return $output;	
			
	}
	add_shortcode('ps_fancybox_list','ps_fancybox_list');
}



/* --- Testimonie Shortcodes --- */

if(!function_exists('ps_testimonie')) {
	function ps_testimonie ( $atts, $content = null) {
		extract(shortcode_atts(array(
			'testimonie_id' => '',
			'style' => '',
			'color' => ''
		
		), $atts));	
		
		$output = '';
		$post = get_post($testimonie_id);
		$title = $post->post_title;
		$content = $post->post_content;
		$position = get_post_meta($post->ID, '_ps_testi_position', true);
		$company = get_post_meta($post->ID, '_ps_testi_company', true);
		$thumb = get_the_post_thumbnail($post->ID);
		$pattern= "/(?<=src=['|\"])[^'|\"]*?(?=['|\"])/i";
		preg_match($pattern, $thumb, $thePath);
		$theSrc = $thePath[0];
		
		
		switch($style) {
			
		case 'style1' :
		
			$output .= '<div class="testi style1">';
			$output .= '<div class="testi-container">';
			$output .= '<blockquote><p>'.$content.'</p></blockquote>';
			$output .= '</div>';
			$output .= '<div class="image"> <img src="'.$theSrc.'" alt="" /> </div>';
			$output .= '<div class="name">'.$title.' <br/><span class="label radius '.$color.'">'.$position.' &ndash; '.$company.'</span> </div></div>';	

		break;
		case 'style2' :
		
			$output .= '<div class="testi style2">
						  <div class="image"> <img src="'.$theSrc.'" alt="'.$title.'" /> </div>
						  <div class="name '.$color.'">'.$title.' <br/>
							<span class="label white radius">'.$position.' &ndash; '.$company.'</span> </div>
						  <div class="testi-container">
							<blockquote>
							  <p>'.$content.'</p>
							</blockquote>
						  </div>
						</div>';	

		break;
		case 'style3' :
		
			$output .= '<div class="testi style3">
						  <div class="testi-container '.$color.'">
							<blockquote>
							  <p>'.$content.'</p>
							</blockquote>
						  </div>
						  <div class="image"> <img src="'.$theSrc.'" alt="'.$title.'" /> </div>
						  <div class="name">'.$title.' <br/>
							<span class="label radius '.$color.'">'.$position.' &ndash; '.$company.'</span> </div>
						</div>';	

		break;
		case 'style4' :
		
			$output .= '<div class="testi style4">
						<div class="testi-container">
						  <blockquote>
							<p>&quot;'.$content.'&quot;</p>
						  </blockquote>
						</div>
						<div class="name '.$color.'"> <span> <i class="icon-comment"></i> '.$title.' </span> </div>
						</div>';	

		break;
		case 'style5' :
		
			$output .= '<div class="testi style5">
						  <div class="testi-container">
							<blockquote>
							  <p>'.$content.'</p>
							</blockquote>
						  </div>
						  <div class="name">'.$title.' <br/>
							<span class="label radius '.$color.'">'.$position.' &ndash; '.$company.'</span> </div>
						</div>';	

		break;
		case 'style6' :
		
			$output .= '<div class="testi style6"> <img src="'.$theSrc.'" alt="'.$title.'" />
						  <div class="testi-wrap">
							<div class="name">
							  <h4 class="'.$color.'">'.$title.'</h4>
							  <span>'.$position.' &ndash; '.$company.'</span> </div>
							<div class="testi-container">
							  <blockquote>
								<p>'.$content.'</p>
							  </blockquote>
							</div>
						  </div>
						</div>';	
		break;
			
		}
		
		return $output;
	
	}

	add_shortcode('ps_testimonie','ps_testimonie');
}

/* --- Testimonial Full width Shortcodes --- */
if(!function_exists('ps_testimonial_full')) {
	function ps_testimonial_full ( $atts, $content = null) {
		extract(shortcode_atts(array(
			'testimonie_id' => '',
		
		), $atts));	
		
		$output = '';
		$output .= '<ul class="front-testi-wrapper large-block-grid-4 medium-block-grid-2 small-block-grid-2 mp-block-grid-1">';

		$selected_testi = array();
	if($testimonie_id) {
		
		$selected_testi = explode(',', $testimonie_id);
		$i = 0;
		foreach  ($selected_testi as $testimonie) { 
			$i++;
			if($i <= 2) {$data_animation = 'data-animate="fadeInLeft"';} else { $data_animation = 'data-animate="fadeInRight"'; }
			$post = get_post($testimonie);
			$title = $post->post_title;
			$content = $post->post_content;

			$position = get_post_meta($post->ID, '_ps_testi_position', true);
			$company = get_post_meta($post->ID, '_ps_testi_company', true);
			$background_overlay_color = get_post_meta($post->ID, '_ps_testi_overlay_color', true);
			$background_testi = get_post_meta($post->ID, '_ps_testi_image', true);
			$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'full' );		
			$image = $thumb[0];
			if($i <= 4) {
			$output .='<li>
				  <div class="front-testi '.$background_overlay_color.' triggerAnimation animated" '.$data_animation.' style="background:url('.$background_testi.');background-size:100% 100%;">
					<blockquote>
					  <p>'.$content.'</p>
					</blockquote>
					<div class="testi-image"> <img src="'.$image.'" alt="" /> </div>
					<div class="testi-name">'.$title.' <br/>
					  <span class="label round white">'.$position.' of '.$company.'</span> </div>
				  </div>
				</li>'; }
		
		
		}
		
	} else {
			
		$args = array(
			'post_type' => 'testi',				
			'showposts' => 4,
		);

		$testi_items = new WP_Query($args);		
		$i = 0;
		while($testi_items->have_posts()): $testi_items->the_post();
		$i++;
		if($i <= 2) {$data_animation = 'data-animate="fadeInLeft"';} else { $data_animation = 'data-animate="fadeInRight"'; }
		global $post;
		$position = get_post_meta($post->ID, '_ps_testi_position', true);
		$company = get_post_meta($post->ID, '_ps_testi_company', true);
		$background_overlay_color = get_post_meta($post->ID, '_ps_testi_overlay_color', true);
		$background_testi = get_post_meta($post->ID, '_ps_testi_image', true);
		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ),'full' );		
		$image = $thumb[0];
		$output .='<li>
				  <div class="front-testi '.$background_overlay_color.' triggerAnimation animated" '.$data_animation.' style="background:url('.$background_testi.');background-size:100% 100%;">
					<blockquote>
					  <p>'.get_the_content().'</p>
					</blockquote>
					<div class="testi-image"> <img src="'.$image.'" alt="" /> </div>
					<div class="testi-name">'.get_the_title().' <br/>
					  <span class="label round white">'.$position.' of '.$company.'</span> </div>
				  </div>
				</li>';
		
		endwhile;
		wp_reset_postdata();
		
		}
			
				
		
		
		$output .= '</ul>';
		
	return $output;
	
	}

	add_shortcode('ps_testimonial_full','ps_testimonial_full');
}



/* --- Teaser Shortcodes --- */

if (!function_exists('ps_teaser')) {
	function ps_teaser( $atts, $content = null) {
		extract(shortcode_atts(array(
			'title' => '',
			'image' => '',
			'link_label' => '',
			'link' => '',
			'ps_animation' => ''
		
		), $atts));
		
			$link = ($link=='||') ? '' : $link;
			$link = ps_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			
			$image_data = wp_get_attachment_image_src( $image, 'full');
			$image_src = $image_data['0'];
			
			$animation = '';
			$data_animation = '';		
			if($ps_animation != 'noAnimation') { $animation = '  mo-animate '; $data_animation = 'data-animate="'.$ps_animation.'"'; };

		
		return '<div class="feature-right '.$animation.'" '.$data_animation.'>
                  <div class="no-shape">
                     <img class="img-border dark img-circle img-shadow gap" data-top="30" src="'.$image_src.'" alt="'.$title.'">
                  </div>    
                  <span class="heading-line"></span>
                  <h3>'.$title.'</h3> 
                  <p>'.$content.'</p>
                  <a class="button link" href="'.$a_href.'" title="'.$a_title.'" targe="'.$a_target.'">'.$link_label.' <i class="icon-chevron-right"></i></a>
               </div>';
		
	}
	add_shortcode('ps_teaser','ps_teaser');
}

/* --- Teaser Shortcodes --- */

if (!function_exists('ps_numbered_box')) {
	function ps_numbered_box( $atts, $content = null) {
		extract(shortcode_atts(array(
			'title' => '',
			'image' => '',
			'align' => '',
			'process_number' => '',
			'link_label' => '',
			'link' => '',
			
		
		), $atts));
		
			$link = ($link=='||') ? '' : $link;
			$link = ps_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			$link_html = '';
			if($a_href != '') {
				$link_html = '<a class="button link" href="'.$a_href.'" title="'.$a_title.'" targe="'.$a_target.'">'.$link_label.' <i class="icon-chevron-right"></i></a>';
			} 
			$align_html = '';
			$number = '';
			if($align != '' && $align != 'center' ) {$align_html = '-'.$align; $number = '2';} 
			$image_data = wp_get_attachment_image_src( $image, 'boxesImages');
			$image_src = $image_data['0'];
		
		return '<div class="feature'.$align_html.' process">
				<div class="no-shape"> <img src="'.$image_src.'" class="img-border dark img-circle img-shadow" alt=""> <span class="process-number'.$number.'">'.$process_number.'</span> </div>
				<h5>'.$title.'</h5>
				<p>'.$content.'</p>
				' . $link_html . '
			  </div>';
		
		
	}
	add_shortcode('ps_numbered_box','ps_numbered_box');
}




/* --- Accordion Shortcodes --- */

if (!function_exists('ps_accordion')) {
	function ps_accordion( $atts, $content = null ) {
	    extract(shortcode_atts(array(
			'title'    	 => 'Title goes here'
	    ), $atts));

		return '<div class="accordion-title">'.$title.'</div><div class="accordion-content">'. do_shortcode($content) .'</div>';
	}
	add_shortcode('ps_accordion', 'ps_accordion');
}

/* Progress bar Shortcodes --- */

if (!function_exists('ps_progress_bar')) {
	function ps_progress_bar( $atts, $content = null ) {
	    extract(shortcode_atts(array(
			'title' => '',
			'types' =>  '',
			'color'     => '',
			'percent' => '',
			'icon' => '',
			'ps_animation' => '',
			'ps_animation_delay' => '',
	    ), $atts));
		
		$animation = '';
		$animation_delay = '';
		$data_animation = '';

		if($ps_animation != 'noAnimation') { 
			$animation = ' mo-animate'; $data_animation = psAnimation($ps_animation); 
		};
		if($ps_animation != 'noAnimation' && $ps_animation_delay != '' ) {
			$animation_delay = 'data-delay="'.$ps_animation_delay.'"';
		}
		
		if($types != 'thermo') {
			return '<div class="progress-bar '.$types.' '.$animation.'" data-percent="'.$percent.'" '.$data_animation.' '.$animation_delay.'><div class="progress-content '.$color.'"><span class="progress-title">'.$title.'</span></div></div>';
		} else {
			return '<div class="progress-bar '.$types.' '.$animation.'" data-percent="'.$percent.'" '.$data_animation.' '.$animation_delay.'><div class="progress-content '.$color.'"><span class="progress-title"><i class="colored '.$icon.'"></i></span></div></div>';
		
		}
	}
	add_shortcode('ps_progress_bar', 'ps_progress_bar');
}

/* --- Progress bar  trigger Shortcodes --- */

if (!function_exists('ps_progress_trigger')) {
	function ps_progress_trigger( $atts, $content = null ) {
		 extract(shortcode_atts(array(
			'el_class' => '',
	    ), $atts));

		return '<div class="progress-trigger '.$el_class.'">'. do_shortcode($content) .'</div>';
	}
	add_shortcode('ps_progress_trigger', 'ps_progress_trigger');
}


/* --- Recent project Grid Shortcodes --- */

if(!function_exists('ps_portfolio_grid')) {
	function ps_portfolio_grid( $atts, $content = null) {
		extract (shortcode_atts(array(
			'items' => '12',
			'columns' => '4',
			'categories' => '',
			'isotope' => 'yes',
			'filter' => ''
		) , $atts));				
	
	if($isotope == 'yes')
	{
		wp_enqueue_script('ps-isotope');
	}
	$selected_categories = array();
	if ($categories != '') {$selected_categories = explode(',', $categories);
		} else {
		$portfolio_category = get_terms('portfolios');
		if($portfolio_category):
			foreach($portfolio_category as $portfolio_cat):
				array_push($selected_categories,$portfolio_cat->slug);
			endforeach;
		endif;
		}
		
	$args = array(
				'post_type' => 'portfolio',				
				'showposts' => $items,
				'tax_query' => array(
        array(
            'taxonomy' => 'portfolios',
            'field' => 'slug',
            'terms' => $selected_categories
        )
    )
						
);	
	$gallery = new WP_Query($args);
	$output = '';
	if( $filter == 'true' && (count($selected_categories)>1) ) {
		$portfolio_category = get_terms('portfolios');
		$i = 300;
		if($portfolio_category):		
		$output .= '<div id="portfolio-filter" class="gap" data-bottom="70">'; 		
		$output .= '<ul>'; 
		$output  .= '<li><a data-animate="bounceIn" href="" class="button button-border mo-animate radius selected" data-filter="*">All</a></li>';		
			foreach($portfolio_category as $portfolio_cat):			
            	if (in_array($portfolio_cat->slug, $selected_categories)) { 
    				$output .= '<li><a data-animate="bounceIn" data-delay="'.$i.'" class="button button-border mo-animate radius" data-filter=".'.$portfolio_cat->slug.'" href="#">'.$portfolio_cat->name.'</a></li>';
				$i = $i+300;	
			 } 
			endforeach;
		$output .= '</ul></div>'; 
		endif;	
	}
	if($isotope != 'no') {
		$output .= '<ul class="portfolio-container large-block-grid-'.$columns.' medium-block-grid-'.$columns.' small-block-grid-1 no-gutter">';
	} else {
		$output .= '<ul class="portfolio-container large-block-grid-'.$columns.' medium-block-grid-'.$columns.' medium-potrait-block-grid-2 small-block-grid-2 small-potrait-block-grid-1 no-gutter gap" data-top="60" data-bottom="30">';
	}
	
	
	if($gallery->have_posts()){
		$li_delay = '300';
		while($gallery->have_posts()): $gallery->the_post();	
			
			if(has_post_thumbnail()){
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery->post->ID ),'portfolioGrid' );
				$full_size = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery->post->ID ),'full' );
			}	
	
			if(!empty($thumb['0'])) { $src_thumb = $thumb['0']; } else { $src_thumb = ''; }
			if(!empty($full_size['0'])) { $src_full = $full_size['0']; } else { $src_full = ''; }
			

			$item_classes = '';			
			$item_cats = get_the_terms($gallery->post->ID, 'portfolios');
			if($item_cats):
			foreach($item_cats as $item_cat) {
				$item_classes .= $item_cat->slug . ' ';
				$category = $item_cat->name;
			}
			endif;
			if($isotope == 'no') {
				$li_class = 'class="mo-animate" data-animate="bounceIn" data-delay="'.$li_delay.'"';
			} else {$li_class = 'class="'.$item_classes.'"';}
			$output .= '<li '.$li_class.'>
                     <div class="mo-caption move">
                        <img src="'.$src_thumb.'" alt="'.get_the_title($gallery->post->ID).'">
                        <div class="mask"></div>
                        <div class="content">
                           <a href="'.$src_full.'" class="preview fancybox" data-fancybox-group="gallery" title="'.get_the_title($gallery->post->ID).'">
                              <i class="icon-search"></i>
                           </a>
                           <a href="'.get_permalink($gallery->post->ID).'" class="permalink white"><i class="icon-link"></i></a>
                        </div>
                     </div>              
                  </li>';
		
		$li_delay = $li_delay + 300;
		endwhile;
		wp_reset_postdata();			
	
	}
	
	$output .= '</ul>';	
	
	return $output;	
	}
	add_shortcode('ps_portfolio_grid', 'ps_portfolio_grid');

}


/* --- ProdigyStudio Portfolio Carousel Shortcodes --- */

if(!function_exists('ps_portfolio_carousel')) {
	function ps_portfolio_carousel( $atts, $content = null) {
		extract (shortcode_atts(array(
			'items' => '6',			
			'categories' => '',
		) , $atts));				
				
	$selected_categories = array();
	if ($categories != '') {$selected_categories = explode(',', $categories);
		} else {
		$portfolio_category = get_terms('portfolios');
		if($portfolio_category):
			foreach($portfolio_category as $portfolio_cat):
				array_push($selected_categories,$portfolio_cat->slug);
			endforeach;
		endif;
		}
		
	$args = array(
				'post_type' => 'portfolio',				
				'showposts' => $items,
				'tax_query' => array(
        array(
            'taxonomy' => 'portfolios',
            'field' => 'slug',
            'terms' => $selected_categories
        )
    )
						
);  
	$gallery = new WP_Query($args);
	$output = '';		
	if($gallery->have_posts()){
		$output .= '<div id="carousel-team">';
		while($gallery->have_posts()): $gallery->the_post();	
			
			if(has_post_thumbnail()){
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery->post->ID ),'portfolioCarouselThumbs' );
				$full_size = wp_get_attachment_image_src( get_post_thumbnail_id( $gallery->post->ID ),'full' );
			}	
	
			if(!empty($thumb['0'])) { $src_thumb = $thumb['0']; } else { $src_thumb = ''; }
			if(!empty($full_size['0'])) { $src_full = $full_size['0']; } else { $src_full = ''; }
			

			$item_classes = '';			
			$item_cats = get_the_terms($gallery->post->ID, 'portfolios');
			if($item_cats):
			foreach($item_cats as $item_cat) {
				$item_classes .= $item_cat->slug . ' ';
				$category = $item_cat->name;
			}
			endif;
		$output .= '<div class="item">';
		$output .= '<div class="mo-caption move"> <img src="'.$src_thumb.'" class="img-border" alt="">';
		$output .= '<div class="mask"></div>
			<div class="content"> 
				<a href="'.$src_full.'" class="preview fancybox" data-fancybox-group="gallery" title="'.get_the_title($gallery->post->ID).'"> <i class="icon-search"></i> </a> 
				<a href="'.get_permalink($gallery->post->ID).'" class="permalink white"><i class="icon-link"></i></a> 
			</div>';
		$output .= '</div>';
		$output .= '</div>';

		endwhile;
		wp_reset_postdata();			
		$output .= '</div>';
	} 
	else {
			
			$output .= '<div data-animate="bounceIn" class="alert-box red mo-animate">
                  <i class="icon-warning-sign"></i>There is no items in portfolio posts. Please, add some items.<a class="close" href="#" data-component="alert">×</a></div>';	
		}
		
	return $output;	
	}
	add_shortcode('ps_portfolio_carousel', 'ps_portfolio_carousel');
}

/* --- Circular bar Shortcodes --- */

if (!function_exists('ps_circular')) {
	function ps_circular( $atts, $content = null ) {
	    extract(shortcode_atts(array(					
			'title' => '',
			'types' => '',
			'color'   => '',
			'percent' => ''
	    ), $atts));
		
		$title_data = '';
		$color_html = '';
		if($title != '') {$title_data = '<h6 data-top="20" class="gap">'.$title.'</h6>';}
		if($color != '') {$color_html = '-'.$color;}

		return '<div class="chart-trigger"><div class="chart'.$types.$color_html.'" data-percent="'.$percent.'"></div>'.$title_data.'</div>';
	}
	add_shortcode('ps_circular', 'ps_circular');
}

/* --- ProdigyStudio Price plan --- */

if(!function_exists('ps_price_plan')) {
	function ps_price_plan( $atts, $content =  null) {
		extract(shortcode_atts(array(
			'columns' => ''
		), $atts));		
		return '<ul class="large-block-grid-'.$columns.' medium-block-grid-'.$columns.' medium-potrait-block-grid-2 small-block-grid-1 gap" data-top="50">'.do_shortcode($content).'</ul>';		
	}
	add_shortcode('ps_price_plan','ps_price_plan');		
}

/* --- ProdigyStudio Price column --- */

if(!function_exists('ps_price_column')) {
	function ps_price_column( $atts, $content = null ) {
		extract(shortcode_atts(array(
			'style' => '',
			'title' => '',
			'color' => '',
			'price' => '',
			'currency' => '',
			'link_label' => '',
			'items' => '',
			'link' => '',
			'icon' => '',
			'shape' => '',
			'ps_animation' => '',
			'ps_animation_delay' => '',

			
			), $atts));	
						
			$animation = '';
			$animation_delay = '';
			$data_animation = '';	
			$link = ($link=='||') ? '' : $link;
			$link = ps_build_link( $link );
			$a_href = $link['url'];
			$a_title = $link['title'];
			$a_target = $link['target'];
			$link_icon = '';
			$shaped_icon = '';
			$noshape_icon = '';
			if($style == 'style3') {
				$shaped_icon = '<div class="'.$shape.' style2 '.$color.'"> <i class="'.$icon.'"></i> </div>';
			}
			if($style == 'style4') {
				$noshape_icon = '<div class="no-shape large"><i class="'.$icon.'"></i></div>';
			}			
			if($style == 'style2' || $style == '') {
				$link_icon = '<i class="icon-circleright"></i>';
			}
			if($ps_animation != 'noAnimation') { 
				$animation = 'class="mo-animate"'; $data_animation = psAnimation($ps_animation); 
			};
			if($ps_animation != 'noAnimation' && $ps_animation_delay != '' ) {
				$animation_delay = 'data-delay="'.$ps_animation_delay.'"';
			}
			
			
			$price_items = explode(',', $items);
			$output = '';			
			$output .= '<li '.$animation.'" '.$data_animation.' '.$animation_delay.'><ul class="pricing-table '.$style.'">';
			$output .= '<li class="title '.$color.'">'.$title.$shaped_icon.'</li>';			
			$output .= '<li class="price '.$color.'"> <span class="currency">'.$currency.'</span> '.$price.$noshape_icon.' </li>';			
			if(!empty($content)) {
				$output .= '<li class="description">'.$content.'</li>';			
			}
			foreach ($price_items as $price_item) {
				$output .='<li class="bullet-item">'.$price_item.'</li>';
			}			
			$output .= '<li class="cta-button text-center"> 
			<a class="button radius '.$color.'" href="'.$a_href.'" title="'.$a_title.'" target="'.$a_target.'">'.$link_label.' '.$link_icon.'</a> </li>';			
			$output .='</ul></li>';
			
		return $output;	

	}
	add_shortcode('ps_price_column','ps_price_column');
}

/* --- ProdigyStudio Timeline container --- */

if (!function_exists('ps_timeline')) {
	function ps_timeline( $atts, $content =  null) {
		
		return '<ul class="timeline">'.do_shortcode($content).'</ul>';
		
	}
	add_shortcode('ps_timeline', 'ps_timeline');
}

/* ProdigyStudio Timeline Item --- */

if (!function_exists('ps_timeline_item')) {
	function ps_timeline_item( $atts, $content =  null) {
		extract(shortcode_atts(array(
			'title' =>'',
			'item_type' => 'custom',
			'blog_post_id' => '',
			'enable_fold' => '',
			'shape' => '',
			'icon' => '',			
			'ps_animation' => '',
		), $atts));
		
		$effect_class = '';
		$effect_data = '';
		if($ps_animation != 'noAnimation') {
			$effect_class = 'mo-animate';
			$effect_data = ' data-animate="'.$ps_animation.'"';
		} else {
			$effect_class = 'mo-animate';
			$effect_data = ' data-animate="fadeInDown"';
		}
		
		$before_fold = '';
		$after_fold = '';
		$icon_style = 'style3';
		if($enable_fold == 'yes') {
			$before_fold = '<div class="panel fold">';
			$after_fold = '</div>';
			$icon_style = 'style2';
			
		}
		
		switch($item_type) {
	
		case "custom" :

			return '<li class="'.$effect_class.'" '.$effect_data.'>
					  <div class="timeline-container">
					  	'.$before_fold.'
						<div class="feature-left">
						  <div class="'.$shape.' small '.$icon_style.'"> <i class="'.$icon.'"></i> </div>
						  <h5 class="gap" data-top="20" data-bottom="12">'.$title.'</h5>
						  <p>' . do_shortcode($content) . '</p>
						</div>
						'.$after_fold.'
					  </div>
					</li>';		
		break;
		
		case "blog_post" :
			
			global $post;
			$post = get_post($blog_post_id);
			$title = $post->post_title;
			$content = $post->post_content;
			$permalink_post = get_permalink($blog_post_id);
			$numbs_comments = get_comments_number($blog_post_id);
			$comments_link = get_comments_link($blog_post_id);
			$output = '';
			
			$output .=  '<li class="'.$effect_class.'" '.$effect_data.'><div class="timeline-container"> <a href="'.$permalink_post.'"><h5>'.$title.'</h5></a>';
	  			
				ob_start();
				get_template_part( 'timeline', get_post_format($blog_post_id) );
				$output .= ob_get_contents();  
			    ob_end_clean(); 
						
			$output .= '</div>
				<div class="timeline-footer">
				  <div class="footer-content">
					<ul class="inline-list">
					  <li><a href="'.$comments_link.'"><i class="icon-comment"></i> '.$numbs_comments.'</a></li>
					  <!--li><a href="#"><i class="icon-fblike"></i> 105</a></li-->
					</ul>
				  </div>
				  <div class="timeline-social">
					<ul class="social-icon">
					  <li><a class="social-facebook" href="http://www.facebook.com/share.php?u='.$permalink_post.'"></a></li>
					  <li><a class="social-twitter" href="http://twitter.com/home?status='.$permalink_post.'"></a></li>
					  <li><a class="social-linkedin" href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.$permalink_post.'&amp;title='.$title.'&amp;source=LinkedIn"></a></li>
					</ul>
				  </div>
				</div>
			  </li>';	
  		
		return $output;			
		
		break;
	
		}
	}
	add_shortcode('ps_timeline_item', 'ps_timeline_item');
}


/* --- ProdigyStudio Team box --- */ 

if(!function_exists('ps_teambox')) {
	function ps_teambox( $atts, $content = null) {
		extract(shortcode_atts(array(
			'member_id' => '',
			'icon' => '',			
			), $atts));
			
			global $post;
			$id = $member_id;
			$post_content = get_post($id)->post_content;
			$teamDetails = get_post_meta($id, '_ps_team_details',true);
			$socialLinks = get_post_meta($id, '_ps_team_social',true);
			
			if(!empty($teamDetails['position'])) {$position = $teamDetails['position'];} else {$position = '';}
						
			$image_data = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), 'full' );
			$image_src = $image_data['0'];
			
			
						
			$output ='';			
			$output .= '<div class="teambox">';
				$output .= '<img src="'.$image_src.'" alt="" class="team-img gap" data-bottom="-45" />';
				$output .= '<div class="feature-offset team-info panel">';
				if($icon != '') { $output .= '<div class="radius-shape style3 small"> <i class="'.$icon.'"></i> </div>'; }
				$output .= '<h4 class="gap" data-bottom="0">'.get_post($id)->post_title.'</h4>';
				$output .= '<small>'.$position.'</small>';
				if($post_content != '') {$output .= '<p class="gap" data-top="18">'.$post_content.'</p>';}				
				
				if(isset($socialLinks['icon']) &&!empty($socialLinks['icon']) ) //print_r( $socialLinks);					
					{$countSocials = count($socialLinks['icon']);					
					$output .= '<ul class="team-social social-icon radius bg-light float">';
						for($i=0; $i<$countSocials; $i++) {
								$output .= '<li> <a href="'.$socialLinks['url'][$i].'" class="'.$socialLinks['icon'][$i].'"></a> </li>';	
						}
					$output .= '</ul>';	
				}
			$output .= '</div></div>';		
		return $output;
	}
	add_shortcode('ps_teambox','ps_teambox');
}

/* --- ProdigyStudio Team box 2 --- */ 

if(!function_exists('ps_teambox2')) {
	function ps_teambox2( $atts, $content = null) {
		extract(shortcode_atts(array(
			'image' => '',
			'alignment' => '',
			'name' => '',
			'position' => '',			
			'facebook_url' => '',
			'google_url' => '',
			'twitter_url' => ''
			
			
			), $atts));
						
			
			$image_data = wp_get_attachment_image_src( $image, 'full');
			$image_src = $image_data['0'];
						
			$output ='';			
			$output .= '<div class="about-team">';
			$output .= '<img src="'.$image_src.'" alt="" class="img-border img-shadow '.$alignment.'" />';
			$output .= '<div class="content-team">';
			if($facebook_url != '' || $google_url != '' || $twitter_url != '') {
				$output .= '<div class="social-wrapper small-potrait-hide"><ul class="social-icon social-feature">';
					if($facebook_url != ''){ $output .= '<li> <a class="social-facebook" href="'.$facebook_url.'"></a></li>';}
					if($twitter_url != ''){ $output .= '<li> <a class="social-twitter" href="'.$twitter_url.'"></a></li>';}
					if($google_url != ''){ $output .= '<li> <a class="social-google" href="'.$google_url.'"></a> </li>';}
				$output .= '</ul></div>';	
			}
			$output .= '<h3 class="gap" data-bottom="0">'.$name.'</h3>';
			$output .= '<span>'.$position.'</span>';
			if($content != '') {$output .= '<p>'.$content.'</p>';}					
			$output .= '</div></div>';		
				
		return $output;
	}
	add_shortcode('ps_teambox2','ps_teambox2');
}


/* --- ProdigyStudio GoogleMap Shortcodes --- */

if (!function_exists('ps_google_map')) {
	function ps_google_map( $atts, $content = null) {
		extract(shortcode_atts(array(
			'height' => '287',
			'lat' => '52.52398',
			'lng' => '13.4054',
			'marker' => ''
			
		), $atts));
	
		$js = '';
		$output = '';
		$id = 'map'.mt_rand();
		
		if($marker !='' ) {
			$image_data = wp_get_attachment_image_src( $marker, 'full');
			$marker_src = $image_data['0'];
		} else { 
			$marker_src = ''.get_template_directory_uri().'/img/map-marker.png';
		}
		
		$output .= '<div style="border-radius:5px;height:'.$height.'px;width:100%;" id="'.$id.'"></div>';
		
		$js .= '<script>
		jQuery(document).ready(function() {
var l=new GMaps(
	{   el:"#'.$id.'",
		scrollwheel:false,
		lat:'.$lat.',
		lng:'.$lng.',
		zoom:17,
		zoomControl:true,
		zoomControlOpt: {style:"SMALL",position:"TOP_LEFT"},panControl:false,streetViewControl:false,mapTypeControl:false,overviewMapControl:false});
		l.addMarker({lat:'.$lat.',lng:'.$lng.',icon:"'.$marker_src.'"});
		var k=[{stylers:[{hue:"#95a5a6"},{saturation:-100}]},{featureType:"road",elementType:"geometry",stylers:[{lightness:100},{visibility:"simplified"}]},{featureType:"road",elementType:"labels",stylers:[{visibility:"off"}]}];
		l.addStyle({styledMapName:"Styled Map",styles:k,mapTypeId:"map_style"});
		l.setStyle("map_style")
		});		
</script>';


	return $output . $js;

	}
	add_shortcode('ps_google_map','ps_google_map');
}








/* Toggle Shortcodes --- */

if (!function_exists('zilla_toggle')) {
	function zilla_toggle( $atts, $content = null ) {
	    extract(shortcode_atts(array(
			'title'    	 => 'Title goes here',
			'state'		 => 'open'
	    ), $atts));

		return "<div data-id='".$state."' class=\"zilla-toggle\"><span class=\"zilla-toggle-title\">". $title ."</span><div class=\"zilla-toggle-inner\">". do_shortcode($content) ."</div></div>";
	}
	add_shortcode('zilla_toggle', 'zilla_toggle');
}

/* Tabs Shortcodes --- */

if (!function_exists('ps_tabs')) {
	function ps_tabs( $atts, $content = null ) {
		$defaults = array(
			'position' => 'top'
		);
		extract( shortcode_atts( $defaults, $atts ) );

		STATIC $i = 0;
		$i++;

		// Extract the tab titles for use in the tab widget.
		preg_match_all( '/tab title="([^\"]+)"/i', $content, $matches, PREG_OFFSET_CAPTURE );

		$tab_titles = array();
		if( isset($matches[1]) ){ $tab_titles = $matches[1]; }

		$output = '';
		
		$set_positions = array(
			'top'    => 'horizontalTab-Top',
			'bottom' => 'horizontalTab-Bottom',
			'left'   => 'verticalTab-Left',
			'right'  => 'verticalTab-Right'
		);  
		
		if($position !='bottom') {
			if( count($tab_titles) ){
				$output .= '<div id="'.$set_positions[$position].'">';
				$output .= '<ul class="resp-tabs-list">';
	
				foreach( $tab_titles as $tab ){
					$output .= '<li>' . $tab[0] . '</li>';
				}
	
				$output .= '</ul><div class="resp-tabs-container">';
				$output .= do_shortcode( $content );
				$output .= '</div></div>';
			} else {
				$output .= do_shortcode( $content );
			}
		} else {
					if( count($tab_titles) ){
				$output .= '<div id="'.$set_positions[$position].'"><div class="resp-tabs-container">';
				$output .= do_shortcode( $content );
				$output .= '</div>';
				$output .= '<ul class="resp-tabs-list">';
				foreach( $tab_titles as $tab ){
					$output .= '<li>' . $tab[0] . '</li>';
				}
				$output .= '</ul>';
				$output .= '</div>';
			} else {
				$output .= do_shortcode( $content );
			}
		
		}
		

		return $output;
	}
	add_shortcode( 'ps_tabs', 'ps_tabs' );
}

if (!function_exists('ps_tab')) {
	function ps_tab( $atts, $content = null ) {
		$defaults = array( 'title' => 'Tab' );
		extract( shortcode_atts( $defaults, $atts ) );

		return '<div>'. do_shortcode( $content ) .'</div>';
	}
	add_shortcode( 'ps_tab', 'ps_tab' );
}?>