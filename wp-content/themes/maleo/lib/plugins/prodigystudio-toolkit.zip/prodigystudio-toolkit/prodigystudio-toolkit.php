<?php

/*
Plugin Name: ProdigyStudio Toolkit
Description: ProdigyStudio Toolkit for Maleo Theme.
Version: 1.0
Author: ProdigyStudio
Author URI: http://themeforest.net/user/ProdigyStudio
License: GPLv2 or later
*/


require_once('shortcodes/ps-shortcodes.php');
require_once('custom-posts/ps-custom-posts.php');

?>